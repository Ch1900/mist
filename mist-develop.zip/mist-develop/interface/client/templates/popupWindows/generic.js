/**
Template Controllers

@module Templates
*/


/**
The about template

@class [template] popupWindows_generic
@constructor
*/
Template['popupWindows_generic'].onCreated(function () {

});

