/**
Template Controllers

@module Templates
*/


/**
The about template

@class [template] popupWindows_about
@constructor
*/
Template['popupWindows_about'].onCreated(function () {

});

